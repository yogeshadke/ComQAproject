package rok.qaPageObject;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import rok.qa.Utilities.Wrappers;

public class Sf_convert_lead_into_opps {
	
	public String titlesave = SF_Create_lead.titlesave;
	
		public WebDriver ldriver;
		WebDriverWait wait;
		Duration timeoutsec;
		SF_Create_lead sf_create_lead;
		public Sf_convert_lead_into_opps(WebDriver rdriver) {
			
			ldriver = rdriver;
			PageFactory.initElements(rdriver, this);
			
		}

		// 2.identify WebElement
//		
//		@FindBy(xpath = "//input[@type='email']")
//		WebElement sfemail;
//	
		//a[@data-label="Home"]
		@FindBy(xpath = "//a[@data-label='Home']")
		WebElement clickonhome;
		
		//span[@id="window"][contains(text(),'roktesingRP')]
		@FindBy(xpath = "//*[contains(text(),'roktesingRP')]")
		WebElement clickonRP;	
		
		//slot[@class="slds-grid slds-page-header__detail-row"]//span[contains(text(),'roktesingRP roktesingRP')]
		
		@FindBy(xpath = "//slot[@class='slds-grid slds-page-header__detail-row']//span[contains(text(),'roktesingRP roktesingRP')]")
		WebElement clickonRP66;
		
			
			public void creteleadintooppsSF() throws InterruptedException {
				Wrappers.clickJS(clickonhome);
				Thread.sleep(8000);
				Wrappers.clickJS(clickonRP);
				
				
				
				
				
		}
	

}
