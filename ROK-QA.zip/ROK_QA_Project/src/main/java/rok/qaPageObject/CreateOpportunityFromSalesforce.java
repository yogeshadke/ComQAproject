package rok.qaPageObject;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import rok.qa.Utilities.Wrappers;

public class CreateOpportunityFromSalesforce {
	
	public WebDriver ldriver;
	WebDriverWait wait;
	Duration timeoutsec;
	
	public CreateOpportunityFromSalesforce(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(xpath = "//input[@type='email']")
	WebElement sfemail;
	@FindBy(xpath = "//input[@type='password']")
	WebElement sfpassword;
	@FindBy(xpath = "//input[@type='submit']")
	WebElement sfsubit;
	
	@FindBy(xpath = "//div[@class='slds-context-bar']//a[@title='Opportunities']")
	WebElement clickopportunity;
	
	//div[@title="New"]
	@FindBy(xpath = "//div[@title='New']")
	WebElement clicknew;
	//input[@class="slds-input" and@name="Name"]
	@FindBy(xpath = "//input[@class='slds-input' and@name='Name']")
	WebElement enteropportunityname;
	@FindBy(xpath = "(//input[@class='slds-combobox__input slds-input' and@placeholder='Search Accounts...'])[3]")
	WebElement enteraccountname;
			
	@FindBy(xpath = "//lightning-base-combobox-formatted-text[contains(text(),'roktesingRP')]")
	WebElement selectaccount;		
			//button[@aria-label="Stage, --None--"]
	@FindBy(xpath = "//button[@class=\"slds-combobox__input slds-input_faux fix-slds-input_faux slds-combobox__input-value\"and@aria-label=\"Stage - Current Selection: --None--\"]")
	WebElement clickonstage;
			//span[@title="1 - Prospecting"]
	@FindBy(xpath = "//span[@title='1 - Prospecting']")
	WebElement selectstage1;
			//input[@name="CloseDate"]
	@FindBy(xpath = "//input[@name='CloseDate']")
	WebElement clickondate;
	
	@FindBy(xpath = "//span[@class=\"slds-day\"][contains(text(),'20')]")
	WebElement selectdate;
	
	@FindBy(xpath = "//button[@name='SaveEdit']")
	WebElement clickonsave;
			
	@FindBy(xpath = "//span[.='Manage Leads']")
	WebElement clickManageleads;
	@FindBy(xpath = "(//a[contains(text(),'View')])[1]")
	WebElement clickManageleadsview;
	
	
	
	//span[contains(text(),'Edit Lead Source')]
	@FindBy(xpath = "//span[contains(text(),'Edit Lead Source')]")
	WebElement Editsource;
	
	//button[@data-value="Unknown - Rep to Get Lead Source"]
	@FindBy(xpath = "//button[@data-value=\"Unknown - Rep to Get Lead Source\"]")
	WebElement clickonsource;
	//span[contains(text(),'APEX')]
	@FindBy(xpath = "//span[contains(text(),'APEX')]")
	WebElement selectsource;
	//span[@class="slds-checkbox slds-checkbox_standalone"]//input[@name="ROK_BypassPreQualRequirement__c"]
	@FindBy(xpath = "//span[@class=\"slds-checkbox slds-checkbox_standalone\"]//input[@name=\"ROK_BypassPreQualRequirement__c\"]")
	WebElement checkboxcheck;
	
	//button[@class="slds-button slds-button_brand"]
	@FindBy(xpath = "//button[@class=\"slds-button slds-button_brand\"]")
	WebElement clickonsaveedit;
	@FindBy(xpath = "//a[@data-tab-name=\"2 - Deal Packaging\"]")
	WebElement selectstage2;
	//a[@data-tab-name="2 - Deal Packaging"]
	//span[contains(text(),'Mark Stage as Complete')]
	@FindBy(xpath = "//button[@class=\"slds-button slds-button--brand slds-path__mark-complete stepAction active uiButton\"]//span[contains(text(),'Mark as Current Stage')]")
	WebElement MarkStageasComplete;
	//button[contains(text(),'Done')]
	@FindBy(xpath = "//button[contains(text(),'Done')]")
	WebElement stagedone;
	//a[@data-tab-name="3 - Deal Review"]
	@FindBy(xpath = "//a[@data-tab-name=\"3 - Deal Review\"]")
	WebElement selectstage3;
	
	//a[@data-tab-name="4 - Underwriting"]
	@FindBy(xpath = "//a[@data-tab-name='4 - Underwriting']")
	WebElement selectstage4;
	//a[@data-tab-name="5 - Offers Received"]
	
	@FindBy(xpath = "//a[@data-tab-name=\"5 - Offers Received\"]")
	WebElement selectstage5;
	//a[@data-tab-name="6 - Presented Offer"]
	@FindBy(xpath = "//a[@data-tab-name=\"6 - Presented Offer\"]")
	WebElement selectstage6;
	//a[@data-tab-name="7 - Contracts Requested"]
	@FindBy(xpath = "//a[@data-tab-name=\"7 - Contracts Requested\"]")
	WebElement selectstage7;
	//a[@data-tab-name="8 - Contracts Out"]
	@FindBy(xpath = "//a[@data-tab-name=\"8 - Contracts Out\"]")
	WebElement selectstage8;
	
	//a[@data-tab-name="9 - Final U/W"]
	@FindBy(xpath = "//a[@data-tab-name=\"9 - Final U/W\"]")
	WebElement selectstage9;
	
	
	//a[contains(text(),'Financial Info')]
	
	//div[@class="slds-align_absolute-center slds-m-top_medium slds-m-bottom_medium"]//button[contains(text(),'New')]
	
	//input[@name="ROK_TotalDeposits__c"]
	//input[@name="ROK_ofDeposits__c"]
	//input[@name="ROK_ofNegativeDays__c"]
	
	//div[@class="footer-full-width"]//button[@name="SaveEdit"]
	
	//div[@class="slds-align_absolute-center slds-m-top_medium slds-m-bottom_medium cROK_Submission_Table"]//button[contains(text(),'New')]
	
	//input[@name="ROK_HighestOffer__c"]
	
	
public void SFlogin() throws InterruptedException {
		
		ldriver.get("https://rok--rokcommqa.sandbox.lightning.force.com/");
		sfemail.sendKeys("testaress12july@yopmail.com");
		sfpassword.sendKeys("Aress123$");
		sfsubit.click();
	}
	
	

	public void Tocreateopportunity() throws InterruptedException {
		
		Wrappers.clickJS(clickopportunity);
		Wrappers.clickJS(clicknew);
		enteropportunityname.sendKeys(Wrappers.generateUniqueString());
		enteraccountname.sendKeys("roktestingRP");
		Thread.sleep(8000);
		Wrappers.clickJS(selectaccount);
		Wrappers.clickJS(clickonstage);
		Wrappers.clickJS(selectstage1);
		Wrappers.clickJS(clickondate);
		Wrappers.clickJS(selectdate);
		Wrappers.clickJS(clickonsave);
		Thread.sleep(8000);
		Wrappers.clickJS(Editsource);
		Thread.sleep(8000);
		Wrappers.clickJS(clickonsource);
		Thread.sleep(8000);
		Wrappers.clickJS(selectsource);
		Thread.sleep(8000);
		Wrappers.clickJS(checkboxcheck);
		Thread.sleep(8000);
		Wrappers.clickJS(clickonsaveedit);
		Wrappers.clickJS(selectstage2);
		Thread.sleep(8000);
		Wrappers.clickJS(MarkStageasComplete);
		Thread.sleep(8000);
		Wrappers.clickJS(stagedone);
		Thread.sleep(8000);
		Wrappers.clickJS(selectstage3);
		Thread.sleep(8000);
		Wrappers.clickJS(MarkStageasComplete);
		Thread.sleep(8000);
		Wrappers.clickJS(stagedone);
		Thread.sleep(8000);
		Wrappers.clickJS(selectstage4);
		Thread.sleep(8000);
		Wrappers.clickJS(MarkStageasComplete);
		Thread.sleep(8000);
		Wrappers.clickJS(stagedone);
		Thread.sleep(8000);
		Wrappers.clickJS(selectstage5);
		Thread.sleep(8000);
		Wrappers.clickJS(MarkStageasComplete);
		Thread.sleep(8000);
		Wrappers.clickJS(stagedone);
		Thread.sleep(8000);
		Wrappers.clickJS(selectstage6);
		Thread.sleep(5000);
		Wrappers.clickJS(MarkStageasComplete);
		Thread.sleep(8000);
		Wrappers.clickJS(stagedone);
		Thread.sleep(5000);
		Wrappers.clickJS(selectstage7);
		Thread.sleep(5000);
		Wrappers.clickJS(MarkStageasComplete);
		Thread.sleep(8000);
		Wrappers.clickJS(stagedone);
		Thread.sleep(5000);
		Wrappers.clickJS(selectstage8);
		Thread.sleep(5000);
		Wrappers.clickJS(MarkStageasComplete);
		Thread.sleep(8000);
		Wrappers.clickJS(stagedone);
		Thread.sleep(5000);
		Wrappers.clickJS(selectstage9);
		Thread.sleep(5000);
		Wrappers.clickJS(MarkStageasComplete);
		Thread.sleep(8000);
		Wrappers.clickJS(stagedone);
//		Thread.sleep(5000);
//		Wrappers.clickJS(selectstage10);
//		Thread.sleep(5000);
//		Wrappers.clickJS(MarkStageasComplete);
//		Thread.sleep(8000);
//		Wrappers.clickJS(stagedone);
	}

}
