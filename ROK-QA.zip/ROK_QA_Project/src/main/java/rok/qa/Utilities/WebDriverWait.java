package rok.qa.Utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import Basetest.BaseClass;

public class WebDriverWait extends BaseClass {
	
	
	public static void WebdriverWait() {
		
		 WebDriverWait wait = new WebDriverWait();

	        // Example WebElement (replace with your own locator)
	        By elementLocator = By.xpath("//*[contains(text(),'Edit Company')]");

	        // Use a while loop to repeatedly attempt to find and interact with the WebElement
	        while (true) {
	            try {
	                
					// Attempt to find the WebElement
	                WebElement element = driver.findElement(elementLocator);

	                // Wait until the element is clickable
	                wait.until(ExpectedConditions.elementToBeClickable(element));

	                // Perform an action on the element (e.g., click)
	                element.click();

	                // Break out of the loop if the interaction is successful
	                break;
	            } catch (Exception e) {
	                // Handle exception (e.g., log, print, or ignore)
	                System.out.println("Element not found or not interactable yet. Retrying...");
	            }
	        }
		
		
		
		
		
	}

	private void until(ExpectedCondition<WebElement> elementToBeClickable) {
		// TODO Auto-generated method stub
		
	}

	

}
