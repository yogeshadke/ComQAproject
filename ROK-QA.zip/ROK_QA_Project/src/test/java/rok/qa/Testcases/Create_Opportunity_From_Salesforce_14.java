package rok.qa.Testcases;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import Basetest.BaseClass;
import rok.qaPageObject.CreateOpportunityFromSalesforce;
import rok.qaPageObject.IndexPage;
import rok.qaPageObject.NewLeads;
import rok.qaPageObject.SF_Create_lead;

public class Create_Opportunity_From_Salesforce_14 extends BaseClass {
	
	public WebDriver ldriver;
	@Test(groups = {"group1"})
	public void Opportunity() throws InterruptedException {
		// openUrl
		
		CreateOpportunityFromSalesforce newleads1a = new CreateOpportunityFromSalesforce(driver);
		newleads1a.SFlogin();
		newleads1a.Tocreateopportunity();
		
		
		
	}
}
