package rok.qa.Testcases;

import org.testng.annotations.Test;

import Basetest.BaseClass;
import rok.qaPageObject.SF_Create_lead;
import rok.qaPageObject.Sf_convert_lead_into_opps;

	
	
	public class SF_convertlead_Testcase_13 extends BaseClass {
		
		
		@Test(groups = {"group1"})
		 public void convertleadintaccount() throws Exception {
	      // openUrl
	    

	      Thread.sleep(8000);
	      SF_Create_lead sfcrtlead = new SF_Create_lead(driver);
	      sfcrtlead.leadcreatedfromSF();
	      Sf_convert_lead_into_opps crtleatop = new Sf_convert_lead_into_opps(driver);
	      sfcrtlead.createleadfromSF();
	      crtleatop.creteleadintooppsSF();
	      
	      
}
}