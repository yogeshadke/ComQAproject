package rok.qa.Testcases;

import org.testng.annotations.Test;

import Basetest.BaseClass;
import rok.qaPageObject.Convert_Lead_into_account;
import rok.qaPageObject.Convert_Lead_into_opps;
import rok.qaPageObject.IndexPage;

public class Conver_lead_into_account_testcsase_11 extends BaseClass {
	@Test(groups = {"group1"})
	 public void convertleadintaccount() throws Exception {
       // openUrl
       driver.get(url);
       logger.info("Url opened");
       Thread.sleep(5000);

       IndexPage pg = new IndexPage(driver);
       pg.passdata(username, password);
       Thread.sleep(8000);
       Convert_Lead_into_account crt = new Convert_Lead_into_account(driver);
       crt.Convertleadtoaccount();
       
   }

}
