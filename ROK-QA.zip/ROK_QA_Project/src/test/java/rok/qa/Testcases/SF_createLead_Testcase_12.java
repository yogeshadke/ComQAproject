package rok.qa.Testcases;

import org.testng.annotations.Test;

import Basetest.BaseClass;
import rok.qaPageObject.Convert_Lead_into_account;
import rok.qaPageObject.IndexPage;
import rok.qaPageObject.SF_Create_lead;

public class SF_createLead_Testcase_12 extends BaseClass {
	
	
	@Test(groups = {"group1"})
	 public void Sfleadcrt() throws Exception {
      // openUrl
    

      Thread.sleep(8000);
      SF_Create_lead sfcrtlead = new SF_Create_lead(driver);
      sfcrtlead.leadcreatedfromSF();
      Thread.sleep(10000);
      sfcrtlead.createleadfromSF();
      
  }


}
